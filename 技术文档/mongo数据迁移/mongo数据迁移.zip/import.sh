#!/bin/sh
cd /data/program/mongodb-2.4.9/bin
JSON="tables.json"
for i in `cat $JSON`
do
./mongoimport -h 10.206.19.224:27017 -d nubia_browser_test -c ${i//\"/} --file /data/bak/20161017/${i//\"/}.json
done
