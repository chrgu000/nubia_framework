function ShardStats(shard, index, stats) {
  this.shard = shard;
  this.index = index;
  this.stats = stats;
}
