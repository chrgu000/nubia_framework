//公共变量声明如下  
var MP = {
  isIphone: function() {
    return navigator.userAgent.toLowerCase().indexOf("iphone") != -1;
  },
  download: function(e) {
    var ua = navigator.userAgent.toLowerCase(), category;
    if (ua.indexOf("android") != -1) {
      window.location.href = "http://app.2345.cn/2345daohang/Internal/2345daohang_3.1_Internal.apk";
    } else if (ua.indexOf("iphone") != -1) {
      window.location.href = "http://um0.cn/3VrK48";
    }
    if (ua.indexOf("android") != -1 || ua.indexOf("iphone") != -1) {
      category = e.srcElement.className;
      if (category == "logo") {
        cc("download_logo");
      } else if (category == "field") {
        cc("download_news");
      }
    }
  },
  appDownload: function() {
    if (MP.isIphone()) {
      window.location.href = "http://um0.cn/3VrK48";
    } else {
      window.location.href = "http://app.2345.cn/2345daohang/Internal/2345table.apk";
    }
    cc("search_download");
  }
};

var mPublic = {
  bindTouch: function(context, s) {
    M("a", context).bind("click", function() {
      M("#J_search_pop").hide();
      //关闭历史记录
      s && cc(s);
    });
  },
  reset: function(height) {
    M("#m_index")[0].style.cssText = "height:" + height + "px;overflow:hidden;";
  }
};

(function() {
  // localStorage 几乎被所有手机浏览器支持，但程序需照顾不支持 localStorage 的 Opera Mini
  var ls = {
    data: null,
    baseUrl: "http://houtai.2345.net/api/getNavData?app_name=all&platform=all&channel=all&app_ver=all&cids=",
    newsId: 0,
    render: function() {
      // recommend(cid: 11) + recommendpic(cid: 10)
      // this.render_recommend();

      // banner(cid: 20) + ad(cid: 21)
      this.render_banner();

      // hotnews(cid: 30)
      this.render_hotnews();

      // newsurl(uid: 40) + lifeurl(cid: 50) + entertainmenturl(cid: 60)
      this.render_sites();

      // lifetools(cid: 70)
      this.render_lifetools();

      // apprecommend(cid: 81) + apprecommendpic(cid: 80) + fastlink(cid: 82)
      this.render_apps();
    },
    getData: function() {
      // firstly check localStorage
      if (!window.isPrivateMode && window.localStorage && localStorage.getItem("data")) {
        this.data = JSON.parse(localStorage.getItem("data"));
        this.render();
      }
      // secondly fetch data from server
      var url = this.baseUrl;
      // 如果是第一次请求 或者是 Opera Mini 机器
      if (window.isPrivateMode || !window.localStorage || !localStorage.getItem("data")) {
        url += "all";
      } else {
        var flag = false;
        Object.keys(this.data).forEach(function(item, index) {
          var obj = ls.data[item];
          if (obj.cid) flag ? url += "_" + obj.cid + "-" + obj.v : (url += obj.cid + "-" + obj.v, 
          flag = true);
        });
      }
      M.ajax({
        url: url,
        success: function(data) {
          ls.update(data);
          ls.render();
        },
        error: function() {
          return;
        }
      });
    },
    update: function(data) {
      if (window.isPrivateMode) {
        this.data = data;
        return;
      }
      // Opera Mini
      if (!window.localStorage) {
        return;
      }
      if (!localStorage.getItem("data")) {
        localStorage.setItem("data", JSON.stringify(data));
        this.data = data;
      } else {
        var obj = JSON.parse(localStorage.getItem("data"));
        Object.keys(data).forEach(function(item) {
          item !== "reviewstatus" && data[item].v !== obj[item].v && (obj[item] = data[item]);
        });
        this.data = obj;
        localStorage.setItem("data", JSON.stringify(obj));
      }
    },
    render_recommend: function() {
      /* 
       * 渲染模板
       * <li><a href=""><img src="" alt="" />文字</a></li>
      */
      var recommendPic = this.data["recommendpic"].data, recommend = this.data["recommend"].data, len = recommendPic.length, j = len / 2, arr1 = [], arr2 = [], arr3 = [];
      for (var i = 0; i < j; i++) {
        arr1.push('<li><a href="' + recommendPic[i]["u"] + '"><img src="' + recommendPic[i]["img"] + '" alt="">' + recommendPic[i]["t"] + "</a></li>");
      }
      M("#J_recommendPic1").html(arr1.join(""));
      for (var i = j; i < len; i++) {
        arr2.push('<li><a href="' + recommendPic[i]["u"] + '"><img src="' + recommendPic[i]["img"] + '" alt="">' + recommendPic[i]["t"] + "</a></li>");
      }
      M("#J_recommendPic2").html(arr2.join(""));
      /*
        渲染模板
        <li><a href="">文字</a></li>
      */
      for (var k = 0, len = recommend.length; k < len; k++) {
        var temp = "";
        if (recommend[k]["red"]) {
          temp = 'style="color:red"';
        }
        arr3.push('<li><a href="' + recommend[k]["u"] + '" ' + temp + ">" + recommend[k]["t"] + "</a></li>");
      }
      M("#J_recommendText").html(arr3.join(""));
    },
    render_hotnews: function() {
      /* 
        渲染模板
        <li><a href="">文字</a></li>
      */
      var hotnews = this.data["hotnews"].data, arr = [];
      this.newsId = 0;
      for (var i = 0; i < 5; i++) {
        var item = hotnews[i], s = item.c ? 'style="color:' + item.c + '"' : "", str = '<li><a href="' + item.u + '" ' + s + ">" + item.t + "</a></li>";
        arr.push(str);
      }
      M("#hotnews").html(arr.join(""));
      // 2 btns: change news & more news
      /*
        渲染模板
        <a class="trig" id='changeNews' href="">换一换</a>
        <a class="trig" href="">更多新闻</a>
      */
      var btn = this.data["hotnews"].btn;
      // c t u
      var a = M("#changeNews")[0], b = M("#moreNews")[0];
      btn[0].c && (a.style.color = btn[0].c);
      btn[1].c && (b.style.color = btn[1].c);
      a.innerHTML = btn[0].t;
      b.innerHTML = btn[1].t;
      b.setAttribute("href", btn[1].u);
    },
    render_lifetools: function() {
      /*
        渲染模板
        <li><a href=""><img src="" alt="" />天&nbsp;气</a></li>
      */
      var lifeTools = this.data["lifetools"].data, arr = [];
      lifeTools.forEach(function(item) {
        var str = '<li><a href="' + item.u + '"><img src="' + item.img + '" alt="" />' + item.t + "</a></li>";
        arr.push(str);
      });
      M("#J_lifeTools").html(arr.join(""));
    },
    render_apps: function() {
      var appRecommendPic = this.data["apprecommendpic"].data, appRecommend = this.data["apprecommend"].data, fastLink = this.data["fastlink"].data, arr1 = [], arr2 = [], arr3 = [];
      /*
      ` 1.
        渲染模板
        <li><a href=""><p class="imgshow"><img src="" alt="" /><i class="downarrow"></i></p>文字</a></li>
      */
      for (var i = 0, len = appRecommendPic.length; i < len; i++) {
        arr1.push('<li><a href="' + appRecommendPic[i]["u"] + '"><p class="imgshow">' + '<img src="' + appRecommendPic[i]["img"] + '" alt="" />' + '<i class="downarrow"></i></p>' + appRecommendPic[i]["t"] + "</a></li>");
      }
      M("#J_appRecommendPic").html(arr1.join(""));
      /* 
        2. text
        渲染模板
        <li><a href="">文字</a></li>
      */
      for (var k = 0, len = appRecommend.length; k < len; k++) {
        var temp = "";
        if (appRecommend[k]["red"]) {
          temp = 'style="color:red"';
        }
        arr2.push('<li><a href="' + appRecommend[k]["u"] + '" ' + temp + ">" + appRecommend[k]["t"] + "</a></li>");
      }
      M("#J_appRecommendText").html(arr2.join(""));
      /*
        3.
        渲染模板
        <li><a href=""><img src="" alt="" />文字</a></li>
      */
      fastLink.forEach(function(item) {
        var str = '<li><a href="' + item.u + '"><img src="' + item.img + '" alt="" />' + item.t + "</a></li>";
        arr3.push(str);
      });
      M("#J_fastLink").html(arr3.join(""));
    },
    render_sites: function() {
        debugger;
      var newsurl = this.data["newsurl"], lifeurl = this.data["lifeurl"], entertainmenturl = this.data["entertainmenturl"];
      function gao(data) {
        var str = "";
        str += '<div class="m-listD">';
        str += '<div class="m-listD-tit">';
        str += data.cname;
        str += "</div>";
        data = data.data;
        for (var i = 0; i < data.length / 6; i++) {
          str += '<div class="m-listD-item">';
          for (var j = i * 6; j < i * 6 + 6; j++) {
            /*
              渲染模板
              <a href="">文字</a>  
            */
            var item = data[j], s = item.c ? 'style="color:' + item.c + '"' : "";
            item.u = encodeURI(item.u);
            str += '<a href="' + item.u + '" ' + s + ">" + item.t + "</a>";
          }
          str += "</div>";
        }
        str += "</div>";
        return str;
      }
      var ans = "";
      ans += gao(newsurl) + gao(lifeurl) + gao(entertainmenturl);
      M("#J_sites").html(ans);
    },
    render_banner: function() {
      var ad = this.data["ad"].data, banner = this.data["banner"].data;
      // if (ad.length) {
      //   var t = ad[0].t, u = ad[0].u;
      //   M("#m-wordA-a").html(t);
      //   M("#m-wordA-a").attr("href", u);
      //   M("#m-wordA").show();
      // } else {
      //   M("#m-wordA").hide();
      // }
      if (banner.length) {
        var u = banner[0].u, img = banner[0].img;
        M("#m-bannerA-img").attr("src", img);
        M("#m-bannerA-a").attr("href", u);
        M("#m-bannerA").show();
        M("#m-bannerA-close")[0].onclick = function() {
          cc("bannerclose");
          M("#m-bannerA").hide();
        };
      } else {
        M("#m-bannerA").hide();
      }
    },
    changeNews: function() {
      // add event listener
      if (M("#changeNews")[0]) {
        M("#changeNews").click(function() {
          cc("refresh");
          ls.newsId++;
          ls.newsId %= 5;
          var hotnews = ls.data["hotnews"].data, arr = [];
          for (var i = ls.newsId * 5; i < ls.newsId * 5 + 5; i++) {
            var item = hotnews[i], s = item.c ? 'style="color:' + item.c + '"' : "", str = '<li><a href="' + item.u + '" ' + s + ">" + item.t + "</a></li>";
            arr.push(str);
          }
          M("#hotnews").html(arr.join(""));
          M.fade(M("#hotnews")[0]);
        });
      } else {
        setTimeout(ls.changeNews, 100);
      }
    },
    init: function() {
      ls.getData();
      ls.changeNews();
      if (navigator.userAgent.toLowerCase().indexOf("iphone") !== -1) {
        M("#lifetoools").hide();
      }
      var me = this, input1, input2;
      window.onscroll = function() {
        // lazyload.init();

        //处理导航悬浮 m-serch
        var tmp = !MP.isIphone() ? M.getPos(M("#m-serch")[0]).y : M.getPos(M("#mNav")[0]).y;
        // if(M.getScrollHeight() >= (M.getPos(M("#m-serch")[0]).y - 4)){       
        if (M.getScrollHeight() >= tmp - 4) {
          M("#header1").show();
          // M("#header").hide();
          if (document.activeElement.id === "input1") M("#input2")[0].focus();
        } else {
          M("#header1").hide();
          // M("#header").show();
          if (document.activeElement.id === "input2") M("#input1")[0].focus();
        }
        //新闻下拉自动加载
        if (M(".trig-news", M(".m-nav")[0]).hasClass("current")) {
          newsSection.more();
        }
        //重置高度
        mPublic.reset(M("section", M(".swiperIndex")[0])[M(".current", M(".m-nav")[0]).index()].offsetHeight);
      };
      window.onresize = function() {
        //重置高度
        mPublic.reset(M("section", M(".swiperIndex")[0])[M(".current", M(".m-nav")[0]).index()].offsetHeight);
        if (M(".shade1")[0]) {
          M("#J-m-books")[0].style.width = window.innerWidth + "px";
          M(".shade1")[0].style.height = M("#J-m-booksList")[0].offsetHeight + "px";
        }
      };
    }
  };
  ls.init();
})();

var getVideo = function(data) {
  if (data.status == "200") {
    videoSection.render(data);
  }
}, getNews = function(data) {
  if (data.stat) {
    newsSection.render(data);
  }
};

//首页tab切换的几个区块声明如下
var newsSection = {
  inited: false,
  num: 1,
  maxPage: 5,
  init: function(fixedClick) {
    fixedClick ? this.fixedClick = true : this.fixedClick = false;
    if (this.inited) {
      this.fixedClick ? GoTop() : "";
      return;
    }
    M.getCss("css/news_20150603.css");
    M.getScript("http://so.2345.com/2345app/get_app_news.php?nt=0&type=660&callback=getNews");
  },
  render: function(data) {
    //判断新闻接口是否存在下一页数据
    if (data.next == 1) {
      this.next = true;
      this.nextId = data.data[data.data.length - 1].id;
    }
    var oLoading = M('.feed-loading',M("#J-m-newsUI")[0])[0];
    if (oLoading) {
      oLoading.parentNode.removeChild(oLoading);
    }
    var arr = [], tempDiv = "", imgTemp = "";
    for (var i = 0, length = data.data.length; i < length; i++) {
      imgTemp = data.data[i].img ? '<div class="img"><img src="' + data.data[i].img + '" alt=""></div>' : "";
      arr.push('<li><a class="trig" href="' + data.data[i].u + '" onclick="cc(\'hotnewscontent\')">' + imgTemp + '<div class="des"><div class="name">' + data.data[i].t + '</div><div class="from">' + data.data[i].dec + "</div></div></a></li>");
    }
    if (this.num < this.maxPage) {
      arr.push('<div class="feed-loading">正在加载...</div>');
    }
    if (this.nextFlag) {
      //下拉加载数据
      this.loadingData = false;
      tempDiv = document.createElement("div");
      tempDiv.innerHTML = arr.join("");
      M("#J-m-newsUI")[0].appendChild(tempDiv);
      //重置高度
      mPublic.reset(M("section", M(".swiperIndex")[0])[M(".current", M(".m-nav")[0]).index()].offsetHeight);
    } else {
      //初次加载数据
      M("#J-m-newsUI").html(arr.join(""));
      M("#news-loading").hide();
      this.inited = true;
      this.fixedClick ? setTimeout(GoTop, 50) : "";
    }
  },
  more: function() {
    if (this.next && T.getWholeHeight() - (T.getViewport().h + T.getScrollHeight()) <= 390) {
      if (this.loadingData) {
        //正在加载数据，避免下拉数据重复
        return;
      }
      if (this.num >= this.maxPage) { 
        var oLoading = M('.feed-loading',M("#J-m-newsUI")[0])[0];
        if (oLoading) {
          oLoading.parentNode.removeChild(oLoading);
        }
        M('.footer-site')[0].style.display = '';        
        return;
      }
      this.loadingData = true;
      //正在加载数据标识，避免下拉数据重复
      this.num++;
      M.getScript("http://so.2345.com/2345app/get_app_news.php?nt=1&type=660&id=" + this.nextId + "&callback=getNews");
      this.nextFlag = true;
    }
  }
}, videoSection = {
  inited: false,
  init: function(fixedClick) {
    fixedClick ? this.fixedClick = true : this.fixedClick = false;
    if (this.inited) {
      this.fixedClick ? GoTop() : "";
      return;
    }
    M.getCss("css/video_20150603.css");
    M.getScript("http://api.v.2345.com/api.php?ctl=message&api_channel=2345dh&api_ver=v4.3&from=dhm&vcode=1000&sign=CAdVAl9UBwAOVlZXBg1QD1cABgQDBlYDBgxbV1ECVwM=&callback=getVideo");
  },
  render_focus: function(focus) {
    var arr1 = [], arr2 = [], arr3 = [];
    for (var i = 0, length = focus.length; i < length; i++) {
      if (i == 0) {
        arr1.push('<li class="swiper-slide"><a href="' + focus[i]["url"] + '"><img src="' + focus[i]["pic"] + '" alt="" /></a></li>');
        arr2.push('<a href="' + focus[i]["url"] + '">' + focus[i]["introduce"] + "</a>");
        arr3.push('<span class="bullet bullet-active"></span>');
      } else {
        arr1.push('<li class="swiper-slide"><a href="' + focus[i]["url"] + '"><img src="' + focus[i]["pic"] + '" alt="" /></a></li>');
        arr2.push('<a href="' + focus[i]["url"] + '" style="display:none;">' + focus[i]["introduce"] + "</a>");
        arr3.push('<span class="bullet"></span>');
      }
    }
    M(".swiper-wrapper", M("#slider")[0]).html(arr1.join(""));
    M(".swiper-title", M("#slider")[0]).html(arr2.join(""));
    M(".swiper-control", M("#slider")[0]).html(arr3.join(""));
    /*焦点图显示*/
    if (M("#slider").length > 0) {
      var title = M("a", M(".swiper-title")[0]), itemObj = M(".swiper-slide", M(".swiperVideo")[0]), itemLength = itemObj.length;
      var swiper = new Swiper(".swiperVideo", {
        loop: true,
        autoplay: 3e3,
        autoplayDisableOnInteraction: false,
        stopPropagation: !0,
        pagination: ".swiper-control",
        bulletClass: "bullet",
        bulletActiveClass: "bullet-active",
        onSlideChangeStart: function(swiper) {
          var index = swiper.activeIndex;
          if (index > itemLength) {
            index = 1;
          }
          title.css({
            display: "none"
          });
          if (title[index - 1]) {
            title[index - 1].style.display = "block";
          }
        }
      });
    }
  },
  render_recommend: function(recommend) {
    var tv, dy, dm, zy;
    for (var i = 0, length = recommend.length; i < length; i++) {
      if (recommend[i].py == "news") {
        this.render_news(recommend[i]);
      }
      if (recommend[i].py == "tv") {
        recommend[i].name = '电视剧';
        tv = recommend[i];
      }
      if (recommend[i].py == "dy") {
        recommend[i].name = '电影';
        dy = recommend[i];
      }
      if (recommend[i].py == "dm") {
        recommend[i].name = '动漫';
        dm = recommend[i];
      }
      if (recommend[i].py == "zy") {
        recommend[i].name = '综艺';
        zy = recommend[i];
      }
    }
    this.render_jiemu(tv, "http://tv.2345.com/m/");
    this.render_jiemu(dy, "http://dianying.2345.com/m/");
    this.render_jiemu(dm, "http://dongman.2345.com/m/");
    this.render_jiemu(zy, "http://v.2345.com/zongyi/m/");
  },
  render_news: function(news) {
    var arr = [];
    for (var i = 0, length = 4; i < length; i++) {
      arr.push('<li><a href="' + news.list[i].url + '"><div class="img"><img src="' + news.list[i].pic + '" /></div><div class="name">' + news.list[i].title + "</div></a></li>");
    }
    $("#J-m-hotsUI").html(arr.join(""));
  },
  render_jiemu: function(dsj, more) {
    var temp = document.createElement("section"), arr = [];
    temp.className = "sec-block";
    arr.push('<div class="btitle"><h2>' + dsj.name + '</h2><a class="more" href="' + more + '">更多</a></div><div class="bmeta"><ul class="block-small-3">');
    for (var i = 0, length = 6; i < length; i++) {
      arr.push('<li><a href="' + dsj.list[i].url + '"><div class="img"><img src="' + dsj.list[i].pic + '" /><div class="level">' + dsj.list[i].latest + '</div></div><div class="name">' + dsj.list[i].title + "</div></a></li>");
    }
    arr.push("</ul></div>");
    temp.innerHTML = arr.join("");
    M(".main", M("#J-m-vList")[0])[0].appendChild(temp);
  },
  render: function(data) {
    this.inited = true;
    M("#video-loading").hide();
    M(".nav-video").show();
    M(".sec-block").show();
    this.render_focus(data.info.focus);
    this.render_recommend(data.info.recommend);
    this.fixedClick ? setTimeout(GoTop, 50) : "";
    mPublic.bindTouch(M("#J-m-vList")[0], "videocontent");
  }
};

M.ready(function() {
  //如果是iPhone,悬浮搜索框就不显示
  if (MP.isIphone()) {
    M(".m-serch", $(".header_fixed")[0]).hide();
  }
  var swiper = new Swiper(".swiperIndex", {
    startSlide: 0,
    speed: 300,
    auto: !1,
    continuous: !1,
    disableScroll: !1,
    stopPropagation: !1,
    longSwipesRatio: .2,
    moveStartThreshold: 50,
    onFirstInit: function() {
      if (navigator.userAgent.toLowerCase().indexOf("iphone") != -1 || navigator.userAgent.toLowerCase().indexOf("ipad") != -1) {
        // bookSection.init(false);
      } else {
        // gameSection.init(false);
      }
    },
    onSlideChangeStart: function() {
      M(".trig-link").removeClass("current");
      M(M(".trig-link", M(".m-nav")[0]).get(swiper.activeIndex)).addClass("current");
      M(M(".trig-link", M(".m-nav")[1]).get(swiper.activeIndex)).addClass("current");
      // //如果悬浮框已出现
      if (M.getScrollHeight() >= M.getPos(M("#m_index")[0]).y) {
        window.scrollTo(0, M.getPos(M(".m-serch")[0]).y - 5);
      }

      // 模块切换后 header1 肯定隐藏
      M("#header1").hide();
      //重置高度
      mPublic.reset(M("section", M(".swiperIndex")[0])[M(".current", M(".m-nav")[0]).index()].offsetHeight);
    },
    onSlideChangeEnd: function() {
      // if (swiper.activeIndex == 1) {
      //   if (navigator.userAgent.toLowerCase().indexOf("iphone") != -1 || navigator.userAgent.toLowerCase().indexOf("ipad") != -1) {
      //     bookSection.init(false);
      //   } else {
      //     gameSection.init(false);
      //   }
      // }
      if (swiper.activeIndex == 1) {
        newsSection.init(false);
      }
      swiper.activeIndex == 1 && newsSection.init(false);
      swiper.activeIndex == 2 && videoSection.init(false);
      swiper.activeIndex == 3 && newsSection.init(false);

      // if (swiper.activeIndex == 1) {
      //   if (gameSection.moreflag) {
      //     M('.footer-site')[0].style.display = '';
      //   } else {
      //     M('.footer-site')[0].style.display = 'none';
      //   }
      // }
      if (swiper.activeIndex == 1) {
        M('.footer-site')[0].style.display = '';
      }
      
      if (swiper.activeIndex == 1) {
        if (newsSection.num == newsSection.maxPage) {
          M('.footer-site')[0].style.display = '';
        } else {
          M('.footer-site')[0].style.display = 'none';
        }
      }
      
      if (swiper.activeIndex == 0 || swiper.activeIndex == 2) {
        M('.footer-site')[0].style.display = '';
      }
      if (MP.isIphone()) {
        if (swiper.activeIndex == 1) {
          M('.footer-site')[0].style.display = '';
        }
      }


      //如果悬浮框已出现
      // console.log(M.getScrollHeight(), M.getPos(M("#m_index")[0]).y);

      // if (M.getScrollHeight() >= M.getPos(M("#m_index")[0]).y) {
      //   // window.scrollTo(0, M.getPos(M(".m-serch")[0]).y - 5);
      //   // alert('hello')
      // }
      //重置高度
      setTimeout(function() {
        mPublic.reset(M("section", M(".swiperIndex")[0])[M(".current", M(".m-nav")[0]).index()].offsetHeight);
      }, 500);
    }
  });
  window.swiper = swiper;
  M(".trig-link", M(".m-nav")).bind("click", function() {
    window.fixedClick = false;
    if (M(this)[0].parentNode.id == "fixedNav") {
      M("#header1").hide();
      //网速慢时先隐藏
      fixedClick = true;
    }
    $(this).hasClass("trig-home") && cc("firstpage") && fixedClick && GoTop();
    $(this).hasClass("trig-news") && cc("hotnews") && newsSection.init(fixedClick);
    $(this).hasClass("trig-v") && cc("video") && videoSection.init(fixedClick);
    swiper.swipeTo($(this).index());
  });
  //对于一些推广渠道优先显示  
  M(window).bind("load", function() {
    if (!MP.isIphone() && location.href.slice(-4) == "lm_6") {
      swiper.swipeTo(1);
    }
  });
});

//统计  
var Stastics = {
  bindEvent: function() {
    var me = this;
    document.onclick = function(e) {
      e = e || window.event;
      var sE = e.target || e.srcElement;
      if (sE.tagName == "A" && sE.href != "" && sE.href !== "javascript:;") {
        me.allCount(sE.href);
        me.allCount2(sE.href);
      } else {
        sE = sE.parentNode;
        if (sE.parentNode && sE.parentNode.tagName == "A") {
          sE = sE.parentNode;
        }
        if (sE.tagName == "A" && sE.href != "" && sE.href !== "javascript:;") {
            me.allCount2(sE.href);
            me.allCount(sE.href);
        }
      }
    };
  },
  allCount: function(vUrl) {
    var timestamps = Date.parse(new Date());
    var url = "http://union2.50bang.org/web/ajax75?uId2=SPTNPQRLSX&r=" + encodeURIComponent(document.location.href) + "&fBL=" + screen.width + "*" + screen.height + "&ver=mversion20161026&rand=" + timestamps + "&lO=" + encodeURIComponent(vUrl) + "?nytjsplit=" + encodeURIComponent("http://" + location.hostname + "/");
    var _dh = document.createElement("script");
    _dh.setAttribute("type", "text/javascript");
    _dh.setAttribute("src", url);
    document.getElementsByTagName("head")[0].appendChild(_dh);
    return true;
  },
    allCount2: function(vUrl) {
        var timestampss = Date.parse(new Date());
        var url = "http://thp.2345.com/web/ajax154?uId2=SPTNPQRLSX&r=" + encodeURIComponent(document.location.href) + "&fBL=" + screen.width + "*" + screen.height + "&ver=mversion20161026&rand=" + timestampss + "&lO=" + encodeURIComponent(vUrl) + "?nytjsplit=" + encodeURIComponent("http://" + location.hostname + "/");
        var _dh = document.createElement("script");
        _dh.setAttribute("type", "text/javascript");
        _dh.setAttribute("src", url);
        document.getElementsByTagName("head")[0].appendChild(_dh);
        return true;
    },
  clickCount: function(a) {
    var b = arguments, web = "ajax75";
    var timestamp = Date.parse(new Date());
    if (b.length > 1) web = b[1];
    if (a.length > 0) {
      var from = location.search;
      if (from == "?fgz") {
        from = "_fgz";
      } else {
        from = "";
      }
      var c = "http://union2.50bang.org/web/" + web + "?uId2=SPTNPQRLSX&r=" + encodeURIComponent(location.href) + "&ver=mversion20161026&rand=" + timestamp  + "&lO=" + encodeURIComponent(a) + from;
      var c2 = "http://thp.2345.com/web/ajax154?uId2=SPTNPQRLSX&r=" + encodeURIComponent(location.href) + "&ver=mversion20161026&rand=" + timestamp  + "&lO=" + encodeURIComponent(a) + from;
      M.getScript(c2);
      M.getScript(c);
    }
    return true;
  },
  init: function() {
    //window.clickCount = this.clickCount;
    window.cc = this.clickCount;
    this.bindEvent();
  }
};

Stastics.init();

//搜索  
var Search = {
  //from_code: "1749a",
  from_code: "wm744856",
  defaultValue: "",
  think: function(keyword) {
    keyword = encodeURIComponent(keyword);
    var url = "http://m.baidu.com/su?p=3&ie=utf-8&from=wise_web&cb=searchThink&wd=" + keyword + "&t=" + Math.round(new Date().getTime() / 1e3);
    M.getScript(url);
  },
  thinkCallback: function(data) {
    /*var templete ='<li><a href="javascript:;"><span class="key">啊</span>里巴巴</a>'+
            '<div class="op"></div></li>';*/
    // console.log(M.trim(M('.J_search_input').val()))
    if (data.s.length > 0 && M.trim(M(".J_search_input").val()) !== "") {
      //搜索下拉推荐
      M.getScript("http://so.2345.com/index/searchForM.php?wd=" + encodeURIComponent(M(".J_search_input").val()));
      window.getRecommend = function(ret) {
        var search_data = [];
        if (ret) {
          search_data.push('<li><a style="font-weight:bold;color: #0e56a4;" href="' + ret.detailUrl + '" target="_blank">' + ret.name + "</a><div class=\"op\" onclick=\"cc('recommend-search');changeKeyword('" + ret.name + "')\"></div></li>");
        }
        if (localStorage && localStorage.getItem("history")) {
          var history = localStorage.getItem("history");
          var hisArray = history.split(",");
          for (var j = 0; j < hisArray.length; j++) {
            if (hisArray[j].indexOf(data["q"]) != -1) {
              hisArray[j] = hisArray[j].replace(/@@@/g, ",");
              search_data.push('<li><a href="https://yz.m.sm.cn/s?from=' + Search.from_code + "&q=" + encodeURIComponent(hisArray[j]) + '" target="_blank" onclick="Search.addClickCount(\'history_search\', \'' + hisArray[j] + '\');"><span class="key">' + data["q"] + "</span>" + hisArray[j].replace(data["q"], "") + "</a><div class=\"op\" onclick=\"cc('click_search');changeKeyword('" + hisArray[j] + "')\"></div></li>");
              break;
            }
          }
        }
        for (var i = 0; i < data["s"].length; i++) {
          if (i < 5) {
            if (ret && ret.name) {
              //避免百度联想的关键字跟从so.2345.com联想的关键字重复
              if (data["s"][i] != ret.name) {
                search_data.push('<li><a href="https://yz.m.sm.cn/s?from=' + Search.from_code + "&q=" + encodeURIComponent(data["s"][i]) + '" target="_blank" onclick="Search.addClickCount(\'lianxiang_search\', \'' + data["s"][i] + '\');"><span class="key">' + data["q"] + "</span>" + data["s"][i].replace(data["q"], "") + "</a><div class=\"op\" onclick=\"cc('click_search');changeKeyword('" + data["s"][i] + "')\"></div></li>");
              }
            } else {
              search_data.push('<li><a href="https://yz.m.sm.cn/s?from=' + Search.from_code + "&q=" + encodeURIComponent(data["s"][i]) + '" target="_blank" onclick="Search.addClickCount(\'lianxiang_search\', \'' + data["s"][i] + '\');"><span class="key">' + data["q"] + "</span>" + data["s"][i].replace(data["q"], "") + "</a><div class=\"op\" onclick=\"cc('click_search');changeKeyword('" + data["s"][i] + "')\"></div></li>");
            }
          }
        }
        if (M.trim(M(".J_search_input").val()) === "") {
          M(".J_search_pop").hide();
          return;
        }
        if (M.trim(M("#input2").val()) === "") {
          M(".J_search_pop").hide();
          return;
        }
        M(".J_search_list").html(search_data.join(""));
        M(".J_search_pop").removeClass("m-serch-think-history").addClass("m-serch-think");
        M(".J_clearHistory").hide();
        M(".J_closeSearch").show();
        M(".J_search_pop").show();
      };
    } else {
      M(".J_search_pop").hide();
    }
  },
  changeKeyword: function(keyword) {
    M(".J_search_input").val(keyword);
    M(".J_search_clear").show();
    //M('.J_search_input')[0].focus();
    Search.think(keyword);
  },
  setSearchHistory: function() {
    var in_array = function(k, arr) {
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] == k) return true;
      }
      return false;
    };
    var keyword = M(".J_search_input").val();
    keyword = M.trim(keyword);
    keyword = keyword.replace(/^\,+|\,+$/g, "");
    if (keyword) {
      keyword = keyword.replace(/\,+/g, "@@@");
      if (window.localStorage) {
        if (localStorage.getItem("history")) {
          var history = localStorage.getItem("history");
          var hisArray = history.split(",");
          if (!in_array(keyword, hisArray)) {
            if (hisArray.length >= 5) {
              hisArray.splice(4, 1);
            }
            history = hisArray.join(",");
            localStorage.setItem("history", keyword + "," + history);
          }
        } else {
          localStorage.setItem("history", keyword);
        }
      }
    }
  },
  doSearch: function() {
    var in_searchs = "search_" + M(".J_search_input").val();
    if(in_searchs == 'search_')
    {
        cc("null_search");
    }
    else
    {
        cc("search");
        cc(in_searchs);
	cc("keyword_search");
    }
    M(".J_search_pop").hide();
    //document.body.scrollTop = 0;
    if (M(".J_search_input").val() == "") {
      if (navigator.userAgent.toLocaleLowerCase().indexOf("mb2345browser") != -1) {
        window.location.href = "https://yz.m.sm.cn/s?from=" + Search.from_code;
        // window.location.href = "http://m.baidu.com/?from=" + Search.from_code;
      } else {

        // window.open("http://m.baidu.com/?from=" + Search.from_code);
        window.open("https://yz.m.sm.cn/s?from=" + Search.from_code);
      }
    } else {
      M(".J_search_pop").hide();
      //M('#J_search_form')[0].submit();
      if (navigator.userAgent.toLocaleLowerCase().indexOf("mb2345browser") != -1) {
        // http://m.yz2.sm.cn/s?from=
        window.location.href = "https://yz.m.sm.cn/s?from=" + Search.from_code + "&q=" + encodeURIComponent(M(".J_search_input").val());
        // window.location.href = "http://m.baidu.com/s?from=" + Search.from_code + "&word=" + encodeURIComponent(M(".J_search_input").val());
      } else {
        window.open("https://yz.m.sm.cn/s?from=" + Search.from_code + "&q=" + encodeURIComponent(M(".J_search_input").val()));
        // window.open("http://m.baidu.com/s?from=" + Search.from_code + "&word=" + encodeURIComponent(M(".J_search_input").val()));
      }
      try {
        Search.setSearchHistory();
      } catch (e) {
        return false;
      }
    }
    return false;
  },
  addClickCount: function(cname, keyword) {
      var in_searchs = "search_" + keyword;
      cc("search");
      cc(in_searchs);
      cc(cname);
  },
  bindEvents: function() {
    var me = this;
    // M('.J_search_pop').bind('click',function(){
    //   M('.J_search_pop').hide();//关闭历史记录
    // });
    M(".J_search_input").bind("input", function(e) {
      // console.log('hello')
      var keyword = $(this).val();
      if (M.trim(keyword) == "") {
        // if (M.trim(keyword) == '') {
        // console.log('hello')
        if (this.id == "input1") {
          $("#input2").val(keyword);
        } else {
          $("#input1").val(keyword);
        }
        M(".J_search_list").html("");
        M(".J_search_pop").hide();
        M(".J_search_clear").hide();
        // M('.J_search_input').val('');
        return;
      }
      if (this.id == "input1") {
        $("#input2").val(keyword);
      } else {
        $("#input1").val(keyword);
      }
      M(".J_search_clear").show();
      // console.log(keyword)
      me.think(keyword);
    }).bind("keyup", function(e) {
      e = e || window.event;
      if (e.keyCode == 13) {
        me.doSearch();
        return;
      }
    });
    M(".J_search_btn").click(function() {
      var in_search = "search_" + M(".J_search_input").val();
      if(in_search == 'search_')
      {
          cc("null_search");
      }
      else
      {
          cc("search");
          cc(in_search);
	  cc("keyword_search");
      }
      M(".J_search_pop").hide();
      //document.body.scrollTop = 0;
      var inputValue = M(".J_search_input", this.parentNode).val();
      if (inputValue == "") {
        if (navigator.userAgent.toLocaleLowerCase().indexOf("mb2345browser") != -1) {
          //window.location.href = "http://m.baidu.com/?from=" + me.from_code;
	  window.open("https://yz.m.sm.cn/s?from=" + me.from_code);
        } else {
          //window.open("http://m.baidu.com/?from=" + me.from_code);
	  window.open("https://yz.m.sm.cn/s?from=" + me.from_code);
        }
      } else {
        M(".J_search_pop").hide();
        //M('#J_search_form')[0].submit();
        if (navigator.userAgent.toLocaleLowerCase().indexOf("mb2345browser") != -1) {
          // http://m.yz2.sm.cn/s?from=
          window.location.href = "https://yz.m.sm.cn/s?from=" + me.from_code + "&q=" + encodeURIComponent(inputValue);
          // window.location.href = "http://m.baidu.com/s?from=" + me.from_code + "&word=" + encodeURIComponent(inputValue);
        } else {
          // http://m.yz2.sm.cn/s?from=
          window.open("https://yz.m.sm.cn/s?from=" + me.from_code + "&q=" + encodeURIComponent(inputValue));
          // window.open("http://m.baidu.com/s?from=" + me.from_code + "&word=" + encodeURIComponent(inputValue));
        }
        me.setSearchHistory();
      }
    });
    /*M('#J_search_input').bind('focus',function(){
        setTimeout(function () {
          window.scrollTo(0,M.getPos(M('#J_search_input')[0]).y-10);
        }, 100);
      });*/
    // M('.J_search_pop').removeClass('m-serch-think-history').addClass('m-serch-think');
    M(".J_search_input").bind("click", function() {
      // M('.J_clearSearch').removeClass('m-serch-close').addClass('m-serch-clear');
      // M('.J_closeSearch').removeClass('trig').addClass('trig-close'); 
      // M('.J_search_pop').addClass('m-serch-think-history');
      var keyword = M(".J_search_input").val();
      if (keyword == "" && M(".J_search_pop").css("display") == "none") {
        var search_data = [];
        //console.log(localStorage.getItem('appFlag'));
        // if(!localStorage.getItem('appFlag')){
        //   search_data.push('<li class="recom-item"><a class="trig" href="javascript:;" onclick="MP.appDownload()"><img src="pic/data/serch_recom_150806.png" alt=""><div class="name">2345网址导航</div><div class="desc">一键升级，上网速度快5倍</div></a><a class="btn" href="javascript:;" onclick="MP.appDownload()">下载</a></li>');
        // }
        // M('#input1')[0].setAttribute('placeholder', '');
        var history = localStorage.getItem("history");
        if (history) {
          var data = history.split(",");
          if (data.length > 0) {
            for (var i = 0; i < data.length; i++) {
              if (search_data.length < 6 && data[i] && M.trim(data[i])) {
                data[i] = data[i].replace(/@@@/g, ",");
                search_data.push('<li><a href="https://yz.m.sm.cn/s?from=' + Search.from_code + "&q=" + encodeURIComponent(data[i]) + '" target="_blank" onclick="Search.addClickCount(\'history_search\', \'' + data[i] + '\');">' + data[i] + "</a><div class=\"op\" onclick=\"cc('click_search');changeKeyword('" + data[i] + "')\"></div></li>");
              }
            }
          }
        }
        if (history) {
          // M('.J_search_pop').addClass('m-serch-think-history');
          M(".J_search_pop").addClass("m-serch-think-history");
          M(".J_search_list").html(search_data.join(""));
          M(".J_clearHistory").show();
          M(".J_search_pop").show();
        }
      }
    });
    M(".J_search_clear").click(function() {
      M(".J_search_input").val("");
      M("#input1")[0].setAttribute("placeholder", "搜索关键词");
      M("#input2")[0].setAttribute("placeholder", "搜索关键词");
      M(".J_search_pop").hide();
      M(".J_search_clear").hide();
    });
    M(".J_clearSearch").click(function() {
      M(".J_search_pop").hide();
    });
    M(".J_clearHistory").click(function() {
      cc("hisclean-serh");
      if (confirm("清除全部查询历史记录？")) {
        if (window.localStorage) {
          // localStorage.setItem('appFlag', 1);//清除过客户端下载
          localStorage.removeItem("history");
          M(".J_search_pop").hide();
          M(".J_search_list").html("");
        }
      }
    });
    // 2015.11.15 改变输入框默认显示逻辑
    M("#input1").bind("focus", function() {
      if (M.trim(M(".J_search_input").val()) === "") M("#input1")[0].setAttribute("placeholder", "");
    });
    M("#input1").bind("blur", function() {
      if (M.trim(M(".J_search_input").val()) === "") M("#input1")[0].setAttribute("placeholder", "搜索关键词");
    });
    M("#input2").bind("focus", function() {
      if (M.trim(M(".J_search_input").val()) === "") M("#input2")[0].setAttribute("placeholder", "");
    });
    M("#input2").bind("blur", function() {
      if (M.trim(M(".J_search_input").val()) === "") M("#input2")[0].setAttribute("placeholder", "搜索关键词");
    });
  },
  init: function() {
    this.from_code = location.search == "?tg1" ? "1009928a" : "wm744856";
    window.searchThink = Search.thinkCallback;
    window.changeKeyword = Search.changeKeyword;
    window.submitSearch = Search.doSearch;
    this.bindEvents();
  }
};

Search.init();

//滚动条滚动 
var currentPosition, timer, scrollHgt = M.getPos(M(".m-serch")[0]).y;

function GoTop() {
  return;
  timer = setInterval("runToTop(0)", 1);
}

function runToTop(flag) {
  //flag=0时直接定位滚动条高度，flag=1时徐缓定位滚动条高度
  if (flag) {
    currentPosition = M.getScrollHeight();
    currentPosition -= 16;
    if (currentPosition > scrollHgt) {
      window.scrollTo(0, currentPosition);
    } else {
      window.scrollTo(0, scrollHgt);
    }
  } else {
    window.scrollTo(0, scrollHgt);
  }
  if (M.getScrollHeight() == scrollHgt) {
    clearInterval(timer);
  }
}

// Lazyload for Application Module
var lazyload = {
  threshold: 100

  , inView: function(ele) {
    var top = M.getPos(ele).y
      , viewVal = M.getViewport().h
      , scrollVal = M.getScrollHeight();

    if (top <= scrollVal + viewVal + this.threshold) {
      return true;
    }

    return false;
  }

  , downloadPic: function(o, url) {
    var tmp = new Image();
    tmp.onload = function() {
      o.src = url;
    };
    tmp.src = url;
  }

  , init: function() {
    var img = document.getElementsByClassName('thumb');
    for (var i = 0, len = img.length; i < len; i++) {
      var o = img[i];
      if (!this.inView(o) || o.isLoaded) continue;
      o.isLoaded = true;
      this.downloadPic(o, o.getAttribute('data-src'));
    }
  }
};
