(function(g, h) {
    var T = T || {
            version: '1.0.0'
        };
    T.getScript = function(a, b) {
        var c = h.createElement('script'),
            head = h.getElementsByTagName('head')[0],
            b = b || {}, diff = b.diff || 0,
            d = new Date(),
            version;
        if (diff < 60 && diff > 0) {
            version = 'ver=' + d.getMonth() + '.' + d.getDate() + '.' + d.getHours() + '.' + Math.floor(d.getMinutes() / diff)
        } else if (diff >= 60) {
            diff /= 60;
            version = 'ver=' + d.getMonth() + '.' + d.getDate() + '.' + Math.floor(d.getHours() / diff)
        } else {
            version = 'ver=1.0'
        } if (b.charset) {
            c.charset = b.charset
        };
        c.onreadystatechange = c.onload = function() {
            if (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') {
                if (b.callback) {
                    b.callback()
                };
                c.onreadystatechange = c.onload = null;
                c.parentNode.removeChild(c)
            }
        };
        c.onerror = function() {
            T.getScript(a, b);
            if (b.errCb) {
                b.errCb()
            }
        };
        c.src = a + (a.indexOf('?') == -1 ? '?' : '&') + version;
        if (a.indexOf('callback=getVideo') != -1) {
            c.src = a
        }
        head.insertBefore(c, head.firstChild)
    };
    T.getCss = function(a, b) {
        var c = document.createElement("link"),
            b = b || {};
        c.type = "text/css";
        c.rel = "stylesheet";
        c.href = a;
        if (b.charset) {
            c.charset = b.charset
        };
        c.onreadystatechange = c.onload = function() {
            if (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') {
                if (b.callback) {
                    b.callback()
                };
                c.onreadystatechange = c.onload = null
            }
        };
        c.onerror = function() {
            if (b.errCb) {
                b.errCb()
            }
        };
        document.getElementsByTagName("head")[0].appendChild(c)
    };
    T.ready = function(b) {
        var c = [],
            fn, f = false,
            testEl = h.documentElement,
            hack = testEl.doScroll,
            domContentLoaded = 'DOMContentLoaded',
            addEventListener = 'addEventListener',
            onreadystatechange = 'onreadystatechange',
            readyState = 'readyState',
            loaded = /^loade|c/.test(h[readyState]);

        function flush(f) {
            loaded = 1;
            while (f = c.shift()) {
                f()
            }
        }
        h[addEventListener] && h[addEventListener](domContentLoaded, fn = function() {
            h.removeEventListener(domContentLoaded, fn, f);
            flush()
        }, f);
        hack && h.attachEvent(onreadystatechange, fn = function() {
            if (/^c/.test(h[readyState])) {
                h.detachEvent(onreadystatechange, fn);
                flush()
            }
        });
        return (b = hack ? function(a) {
            g.self != g.top ? loaded ? a() : c.push(a) : function() {
                try {
                    testEl.doScroll('left')
                } catch (e) {
                    return setTimeout(function() {
                        b(a)
                    }, 50)
                }
                a()
            }()
        } : function(a) {
            loaded ? a() : c.push(a)
        })
    }();
    T.browser = function(b) {
        var c = b.document,
            ua = navigator.userAgent.toLowerCase(),
            getEnv = function(a) {
                return (a = ua.match(RegExp(a + '\\b[ \\/]?([\\w\\.]*)', 'i'))) ? a.slice(1) : ['', '']
            }, addSearchProviderEnabled = function() {
                return !!(window.external && typeof window.external.AddSearchProvider != 'undefined' && typeof window.external.IsSearchProviderInstalled != 'undefined')
            }, detect360chrome = function() {
                return 'track' in document.createElement('track') && 'scoped' in document.createElement('style')
            }, is360se = false,
            is2345 = function() {
                var a = false;
                try {
                    if (window.external.RCCoralOnlineFavPage('productVersion')) {
                        a = true
                    }
                } catch (e) {
                    a = false
                }
                return a
            }(),
            getMaxthonVer;
        try {
            if (/(\d+\.\d)/.test(b.external.max_version)) {
                getMaxthonVer = parseFloat(RegExp.$1)
            }
        } catch (e) {}
        if (!is2345 && !addSearchProviderEnabled()) {
            try {
                if (String(window.external)) {
                    is360se = true
                }
            } catch (e) {}
        }
        var d = getEnv('(msie|safari|firefox|chrome|opera)'),
            getShell;
        d[0] === 'msie' ? is2345 ? getShell = ['2345explorer', ''] : is360se ? getShell = ['360se', ''] : getMaxthonVer ? getShell = ['maxthon', getMaxthonVer] : getShell == ',' && (getShell = getEnv('(tencenttraveler)')) : d[0] === 'safari' && (d[1] = getEnv('version') + '.' + d[1]);
        getShell = getEnv('(maxthon|360se|360chrome|theworld|se|greenbrowser|qqbrowser|lbbrowser|2345Explorer|2345chrome)');
        if (d[0] === 'chrome') {
            if (detect360chrome()) {
                getShell = 'v8Locale' in window ? ['360se', ''] : ['360chrome', '']
            }
        }
        try {
            if (!getShell[0] && ("" + window.external) == "undefined") {
                getShell = ['msie', '']
            }
        } catch (e) {}
        if (is2345) {
            getShell = ['2345explorer', '']
        }
        return {
            isShell: !! getShell[0],
            shell: getShell,
            types: d,
            chrome: d[0] === 'chrome' && d[1],
            firefox: d[0] === 'firefox' && d[1],
            ie: d[0] === 'msie' && d[1],
            opera: d[0] === 'opera' && d[1],
            safari: d[0] === 'safari' && d[1],
            maxthon: getShell[0] === 'maxthon' && getShell[1],
            isTT: getShell[0] === 'tencenttraveler' && getShell[1]
        }
    }(g);
    T.throttle = function(a, b, c) {
        c = c || 80;
        clearTimeout(a.tId);
        a.tId = setTimeout(function() {
            a.call(b)
        }, c)
    };
    T.addEvent = function(a, b, c) {
        if (a.attachEvent) {
            a.attachEvent && a.attachEvent('on' + b, c)
        } else {
            a.addEventListener(b, c, false)
        }
    };
    T.removeEvent = function(a, b, c) {
        if (a.detachEvent) {
            a.detachEvent && a.detachEvent('on' + b, c)
        } else {
            a.removeEventListener(b, c, false)
        }
    };
    T.getPos = function(a) {
        var b = {
            x: 0,
            y: 0
        };
        while (a.offsetParent) {
            b.x += a.offsetLeft;
            b.y += a.offsetTop;
            a = a.offsetParent
        }
        return b
    };
    T.getViewport = function() {
        var a = document.documentElement;
        return {
            w: (T.browser.ie || !self.innerWidth) ? a.clientWidth : self.innerWidth,
            h: (T.browser.ie || !self.innerHeight) ? a.clientHeight : self.innerHeight
        }
    };
    T.getScrollHeight = function() {
        var a = document,
            html = a.documentElement,
            bd = a.body;
        return Math.max(window.pageYOffset || 0, html.scrollTop, bd.scrollTop)
    };
    T.getWholeHeight = function() {
        var a = 0,
            documentScrollHeight = 0,
            wholeHeight;
        if (document.body) {
            a = document.body.scrollHeight
        }
        if (document.documentElement) {
            documentScrollHeight = document.documentElement.scrollHeight
        }
        return wholeHeight = (a - documentScrollHeight > 0) ? a : documentScrollHeight
    };
    T.beacon = function(a, b) {
        var c = new Image();
        c.onload = c.onerror = c.onabort = function() {
            c.onload = c.onerror = c.onabort = null;
            c = null;
            b && b()
        };
        c.src = a
    };
    T.inView = function(a) {
        var b = T.getPos(a).y,
            viewVal = T.getViewport().h,
            scrollVal = T.getScrollHeight();
        var c = 10;
        if (b >= scrollVal - c && b <= scrollVal + viewVal + c) {
            return true
        }
        return false
    };
    T.setOpacity = function(a, b) {
        if (!a.currentStyle || !a.currentStyle.hasLayout) {
            a.style.zoom = 1
        }
        if (T.browser.ie) {
            a.style.filter = 'alpha(opacity=' + b + ')'
        } else {
            a.style.opacity = b / 100
        }
    };
    T.fade = function(a, b) {
        var c = this;
        var d = 100,
            timer = null,
            counter = 50;
        this.setOpacity(a, 50);
        a.style.display = '';
        var e = function() {
            if (counter <= d) {
                c.setOpacity(a, (counter / d) * 100);
                counter += 10;
                timer = setTimeout(e, 16)
            } else {
                clearTimeout(timer);
                if (b) {
                    b()
                }
            }
        };
        e()
    };
    g['T'] = T;
    if (typeof JSON == 'undefined') {
        g['JSON'] = {};
        g['JSON']['parse'] = function(a) {
            return eval('(' + a + ')')
        }
    }
})(this, document);
(function(l) {
    function $(a) {
        return document.getElementById(a)
    }

    function $c(a) {
        return document.createElement(a)
    }

    function $t(a) {
        var b = arguments[1] || document;
        return b.getElementsByTagName(a)
    }

    function $cls(a) {
        var b = arguments[1] || document,
            rs = [],
            o = b.getElementsByTagName("*");
        for (var i = 0, t, len = o.length; i < len; i++) {
            t = o[i];
            if ((' ' + t.className + ' ').indexOf(' ' + a + ' ') !== -1) {
                rs.push(t)
            }
        }
        return rs
    }
    var m = (/^<(\w+)\s*\/?>$/),
        classSelectorRE = /^\.([\w-]+)$/,
        idSelectorRE = /^#([\w-]*)$/,
        tagSelectorRE = /^[\w-]+$/;
    var M = function(a, b) {
        if (!(this instanceof M)) {
            return new M(a, b)
        }
        this.elements = [];
        var c = a;
        switch (typeof c) {
            case 'function':
                T.ready(c);
                break;
            case 'string':
                b = (b && b.nodeType == 1) ? b : document;
                if (idSelectorRE.test(c)) {
                    this.elements.push($(c.substring(1)))
                } else if (classSelectorRE.test(c)) {
                    if (b.getElementsByClassName) {
                        this.elements = b.getElementsByClassName(c.substring(1))
                    } else {
                        this.elements = $cls(c.substring(1), b)
                    }
                } else if (tagSelectorRE.test(c)) {
                    this.elements = $t(c, b)
                } else if (c.charAt(0) === "<" && c.charAt(c.length - 1) === ">") {
                    var d = m.exec(c);
                    this.elements.push($c(d[1]))
                } else {
                    if (b.querySelectorAll) {
                        this.elements = b.querySelectorAll(c)
                    }
                }
                break;
            case 'object':
                if (c.constructor == Array) {
                    this.elements = c
                } else {
                    this.elements.push(c)
                }
                break
        }
        var i, elements = this.elements,
            len = elements.length;
        for (i = 0; i < len; i++) {
            this[i] = elements[i]
        }
        this.length = len
    };
    M.fn = M.prototype = {
        constructor: M
    };
    M.extend = M.fn.extend = function(a, b) {
        var c = this;
        var i;
        for (i in a) {
            if (b || !(c[i] || (i in c))) {
                c[i] = a[i]
            }
        }
    };
    var p = function(o) {
        if (o != null && o.constructor != null) {
            return Object.prototype.toString.call(o).slice(8, -1)
        } else {
            return ''
        }
    };
    M.extend({
        isString: function(a) {
            return p(a) == 'String'
        },
        isFunction: function(a) {
            return p(a) == 'Function'
        },
        isArray: function(a) {
            return p(a) == 'Array'
        },
        isArrayLike: function(a) {
            return !!a && typeof a == 'object' && a.nodeType != 1 && typeof a.length == 'number'
        },
        isObject: function(a) {
            return a !== null && typeof a == 'object'
        },
        isPlainObject: function(a) {
            return p(a) == 'Object'
        },
        isElement: function(a) {
            return !!a && a.nodeType == 1
        },
        isEmptyObj: function(a) {
            for (var k in a) {
                return false
            }
            return true
        }
    });
    M.trim = function(a) {
        if (a.trim) {
            return a.trim()
        }
        return a.replace(/^\s+|\s+$/g, '')
    };
    M.replaceTmpl = function(c, d) {
        return ("" + c).replace(/\$(\w+)\$/g, function(a, b) {
            return typeof d[b] != "undefined" ? d[b] : "$" + b + "$"
        })
    };
    M.getStyle = function(a, b) {
        if (a.currentStyle) {
            return a.currentStyle[b]
        } else {
            return getComputedStyle(a, false)[b]
        }
    };
    M.extend({
        camelize: function(s) {
            return s.replace(/\-(\w)/ig, function(a, b) {
                return b.toUpperCase()
            })
        },
        decamelize: function(s) {
            return s.replace(/[A-Z]/g, function(a) {
                return "-" + a.toLowerCase()
            })
        }
    });
    M.extend({
        'addClass': function(c, a) {
            if (!a) return;
            a.className = this.hasClass(c, a) ? a.className : a.className + ' ' + c
        },
        'removeClass': function(c, a) {
            var b = new RegExp("(^|\\s+)" + c + "(\\s+|$)", "g");
            if (!this.hasClass(c, a)) return;
            a.className = b.test(a.className) ? a.className.replace(b, '') : a.className
        },
        'hasClass': function(c, a) {
            if (!a || !a.className) return false;
            return a.className.indexOf(c) > -1
        }
    });
    M.ajax = function(b) {
        var c = {
            url: '',
            type: 'GET',
            dataType: 'json',
            async: true,
            data: {},
            timeout: 3000,
            success: function() {},
            error: function() {}
        };
        for (var k in b) {
            c[k] = b[k]
        }
        var d = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        d.onreadystatechange = function() {
            if (d.readyState == 4) {
                if (d.status >= 200 && d.status < 300 || d.status == 304) {
                    try {
                        var a = c.dataType == 'json' ? JSON.parse(d.responseText) : d.responseText;
                        c.success(a)
                    } catch (e) {
                        c.error(d)
                    }
                } else {
                    c.error(d)
                }
            }
        };
        d.open(c['type'], c['url'], c['async']);
        d.send(null)
    };
    M.Cookie = {
        set: function(a, b, c, e, f) {
            if (arguments.length == 1) {
                var g = new Date();
                var h = a.name,
                    _val = a.val,
                    _exps = typeof(a.exps) != "undefined" ? a.exps : 180,
                    _domain = a.domain || window.location.host,
                    _path = a.path || "/",
                    _secure = a.secure || "";
                g.setDate(g.getDate() + _exps);
                var i = h + "=" + escape(_val) + (_exps ? ";expires=" + g.toUTCString() : "") + (_path ? ";path=" + _path : "") + (_domain ? ";domain=" + _domain : "") + (_secure ? ";secure=" : "");
                document.cookie = i
            } else {
                var j = '';
                var k = 'domain=.' + window.location.host;
                if (typeof(c) == "number") {
                    var d = new Date();
                    d.setTime(d.getTime() + c * 1000);
                    j = ';expires=' + d.toGMTString()
                }
                document.cookie = a + '=' + encodeURIComponent(b) + '; path=' + (f ? f : '/') + ';' + (e ? e : k) + j
            }
        },
        get: function(a) {
            var b = document.cookie.match(new RegExp("(^| )" + a + "=([^;]*)(;|$)"));
            if (b != null) return decodeURIComponent(b[2]);
            return null
        }
    };
    M.fn.extend({
        show: function() {
            var i, elements = this.elements,
                len = elements.length;
            for (i = 0; i < len; i++) {
                elements[i].style.display = 'block'
            }
            return this
        },
        hide: function() {
            var i, elements = this.elements,
                len = elements.length;
            for (i = 0; i < len; i++) {
                elements[i].style.display = 'none'
            }
            return this
        }
    });
    M.fn.on = function(a, b) {
        var i, elements = this.elements,
            len = elements.length;
        for (i = 0; i < len; i++) {
            T.addEvent(elements[i], a, b)
        }
        return this
    };
    M.fn.bind = function(a, b) {
        return this.on(a, b)
    };
    M.fn.click = function(a) {
        return this.on('click', a)
    };
    M.fn.extend({
        get: function(i) {
            return this.elements[i] ? this.elements[i] : null
        },
        index: function() {
            var a = this.elements[0].parentNode.children;
            for (var i = 0, length = a.length; i < length; i++) {
                if (a[i] == this.elements[0]) {
                    return i
                }
            }
        }
    });
    M.fn.extend({
        val: function(v) {
            if (arguments.length) {
                var i, elements = this.elements,
                    len = elements.length;
                for (i = 0; i < len; i++) {
                    elements[i].value = v
                }
                return this
            } else {
                return this.elements[0] ? this.elements[0].value : null
            }
        },
        html: function(v) {
            if (arguments.length) {
                var i, elements = this.elements,
                    len = elements.length;
                for (i = 0; i < len; i++) {
                    elements[i].innerHTML = v
                }
                return this
            } else {
                return this.elements[0] ? this.elements[0].innerHTML : null
            }
        },
        text: function(v) {
            if (arguments.length) {
                var i, elements = this.elements,
                    len = elements.length;
                for (i = 0; i < len; i++) {
                    elements[i].innerHTML = v
                }
                return this
            } else {
                return this.elements[0] ? this.elements[0].innerHTML.replace(/<[^<]*>/g, '') : null
            }
        }
    });
    M.fn.attr = function(n, v) {
        if (arguments[1]) {
            var i, elements = this.elements,
                len = elements.length;
            for (i = 0; i < len; i++) {
                n.indexOf('data-') == 0 ? elements[i].setAttribute(n, v) : elements[i][n] = v
            }
            return this
        } else {
            var a = this.elements[0];
            return a ? (n.indexOf('data-') == 0 ? a.getAttribute(n) : a[n]) : null
        }
    };
    M.fn.extend({
        'addClass': function(c) {
            var i, elements = this.elements,
                len = elements.length;
            for (i = 0; i < len; i++) {
                M.addClass(c, elements[i])
            }
            return this
        },
        'removeClass': function(c) {
            var i, elements = this.elements,
                len = elements.length;
            for (i = 0; i < len; i++) {
                M.removeClass(c, elements[i])
            }
            return this
        },
        'hasClass': function(c) {
            return M.hasClass(c, this.elements[0])
        }
    });
    M.fn.css = function(n, v) {
        if (arguments.length > 1) {
            var i, elements = this.elements,
                len = elements.length;
            for (i = 0; i < len; i++) {
                elements[i].style[n] = v
            }
            return this
        } else {
            if (M.isObject(n)) {
                var i, elements = this.elements,
                    len = elements.length;
                for (i = 0; i < len; i++) {
                    for (var k in n) {
                        elements[i].style[k] = n[k]
                    }
                }
            } else {
                var a = this.elements[0];
                return a ? M.getStyle(a, n) : null
            }
        }
    };
    M.extend(T);
    l.M = M;
    if (!l.$) {
        l.$ = M
    }
})(this);